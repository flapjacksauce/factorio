data:extend({
	-- Startup
	{
		type = "double-setting",
		name = "fire-armor-cost",
		setting_type = "startup",
		minimum_value = 0.1,
		default_value = 1,
		maximum_value = 2
	},
	{ 
		name          = 'onStart',
		type          = 'bool-setting',
		setting_type  = 'startup'     ,
		default_value =  false         ,
		order         = 'g-a'         ,
    },
	-- Global
})