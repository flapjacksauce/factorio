--item.lua

    -- Startup settings
local onStart = settings.startup['onStart'].value
local activeOnStart = onStart

local cost = settings.startup["fire-armor-cost"].value


    -------

    -- [Fire] Heavy Armor
local fireArmor = table.deepcopy(data.raw["armor"]["heavy-armor"]) -- copy the table that defines the heavy armor item into the fireArmor variable

fireArmor.name = "fire-armor"
fireArmor.icons = {
  {
    icon = fireArmor.icon,
    tint = {r=1,g=0,b=0,a=0.3}
  },
}

fireArmor.resistances = {
  {
    type = "physical",
    decrease = 6,
    percent = 30
  },
  {
    type = "explosion",
    decrease = 20,
    percent = 30
  },
  {
    type = "acid",
    decrease = 0,
    percent = 40
  },
  {
    type = "fire",
    decrease = 0,
    percent = 100
  }
}

    -- Fire Heavy Armor (Recipe)
local recipe = table.deepcopy(data.raw["recipe"]["heavy-armor"])
recipe.enabled = activeOnStart
recipe.name = "fire-armor"
recipe.ingredients = {
	{"copper-plate",200*cost}           ,
	{"steel-plate",50*cost}             ,
	{"grenade",100*cost}                ,
}
recipe.result = "fire-armor"


    -------

    -- [Fire] Modular Armor
local fireArmor1 = table.deepcopy(data.raw["armor"]["modular-armor"]) -- copy the table that defines the modular armor item into the fireArmor variable

fireArmor1.name = "fire-armor1"
fireArmor1.icons = {
  {
    icon = fireArmor1.icon,
    tint = {r=1,g=0,b=0,a=0.3}
  },
}

fireArmor1.resistances = {
  {
    type = "physical",
    decrease = 6,
    percent = 30
  },
  {
    type = "explosion",
    decrease = 30,
    percent = 35
  },
  {
    type = "acid",
    decrease = 0,
    percent = 50
  },
  {
    type = "fire",
    decrease = 0,
    percent = 100
  }
}

    -- [Fire] Modular Armor (Recipe)
local recipe1 = table.deepcopy(data.raw["recipe"]["modular-armor"])
recipe1.enabled = activeOnStart
recipe1.name = "fire-armor1"
recipe1.ingredients = {
	{"steel-plate",50*cost}             ,
	{"advanced-circuit",30*cost}        ,
	{"explosives",100*cost}             ,
}
recipe1.result = "fire-armor1"


    -------

    -- [Fire] Power Armor
local fireArmor2 = table.deepcopy(data.raw["armor"]["power-armor"]) -- copy the table that defines the power armor item into the fireArmor variable

fireArmor2.name = "fire-armor2"
fireArmor2.icons = {
  {
    icon = fireArmor2.icon,
    tint = {r=1,g=0,b=0,a=0.3}
  },
}

fireArmor2.resistances = {
  {
    type = "physical",
    decrease = 6,
    percent = 30
  },
  {
    type = "explosion",
    decrease = 30,
    percent = 35
  },
  {
    type = "acid",
    decrease = 0,
    percent = 50
  },
  {
    type = "fire",
    decrease = 0,
    percent = 100
  }
}

    -- [Fire] Power Armor (Recipe)
local recipe2 = table.deepcopy(data.raw["recipe"]["power-armor"])
recipe2.enabled = activeOnStart
recipe2.name = "fire-armor2"
recipe2.ingredients = {
	{"steel-plate",40*cost}             ,
	{"processing-unit",40*cost}         ,
	{"electric-engine-unit",20*cost}    ,
	{"rocket",100*cost}                 ,
}
recipe2.result = "fire-armor2"

    -------

    -- [Fire] Power Armor Mk2
local fireArmor3 = table.deepcopy(data.raw["armor"]["power-armor-mk2"]) -- copy the table that defines the heavy armor item into the fireArmor variable

fireArmor3.name = "fire-armor3"
fireArmor3.icons = {
  {
    icon = fireArmor3.icon,
    tint = {r=1,g=0,b=0,a=0.3}
  },
}

fireArmor3.resistances = {
  {
    type = "physical",
    decrease = 10,
    percent = 40
  },
  {
    type = "explosion",
    decrease = 60,
    percent = 50
  },
  {
    type = "acid",
    decrease = 0,
    percent = 70
  },
  {
    type = "fire",
    decrease = 0,
    percent = 100
  }
}

    -- [Fire] Power Armor Mk2 (Recipe)
local recipe3 = table.deepcopy(data.raw["recipe"]["power-armor-mk2"])
recipe3.enabled = activeOnStart
recipe3.name = "fire-armor3"
recipe3.ingredients = {
	{"processing-unit",60*cost}         ,
	{"electric-engine-unit",40*cost}    ,
	{"low-density-structure",30*cost}   ,
	{"speed-module-2",25*cost}          ,
	{"effectivity-module-2",25*cost}    ,
	{"explosive-rocket",100*cost}       ,
}
recipe3.result = "fire-armor3"


-------	[TECHNOLOGY]	
	
	-- This is the technology that will unlock the (Fire) Heavy Armor recipe.
local tech = table.deepcopy(data.raw["technology"]["heavy-armor"])

tech.name = "fire-armor"
tech.prerequisites = {"heavy-armor", "refined-flammables-1"}
tech.effects = {
{ type   = 'unlock-recipe',
  recipe = "fire-armor"
  },  
}
 
tech.unit = {
count = 130,
ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack"  , 1},
  {"military-science-pack"  , 1},
  },
time = 30,
}

tech.icons = {
  {
    icon = tech.icon,
    tint = {r=1,g=0,b=0,--[[a=0.3--]]}
  },
}
	

tech.enabled = true


-------		
	
	-- This is the technology that will unlock the (Fire) Modular Armor recipe.
local tech1 = table.deepcopy(data.raw["technology"]["modular-armor"])

tech1.name = "fire-armor1"
tech1.prerequisites = {"modular-armor", "refined-flammables-3"}
tech1.effects = {
{ type   = 'unlock-recipe',
  recipe = "fire-armor1"
  }, 
}
 
tech1.unit = {
count = 200,
ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack"  , 1},
  {"military-science-pack"  , 1},
  },
time = 30,
}

tech1.icons = {
  {
    icon = tech1.icon,
    tint = {r=1,g=0,b=0,--[[a=0.3--]]}
  },
}
	

tech1.enabled = true    


-------		
	
	-- This is the technology that will unlock the (Fire) Power Armor recipe.
local tech2 = table.deepcopy(data.raw["technology"]["power-armor"])

tech2.name = "fire-armor2"
tech2.prerequisites = {"power-armor", "refined-flammables-5"}
tech2.effects = {
{ type   = 'unlock-recipe',
  recipe = "fire-armor2"
  }, 
}
 
tech2.unit = {
count = 300,
ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack"  , 1},
  {"chemical-science-pack"  , 1},
  {"military-science-pack"  , 1},
  },
time = 30,
}

tech2.icons = {
  {
    icon = tech2.icon,
    tint = {r=1,g=0,b=0,--[[a=0.3--]]}
  },
}
	

tech2.enabled = true


-------		
	
	-- This is the technology that will unlock the (Fire) Power Armor Mk2 recipe.
local tech3 = table.deepcopy(data.raw["technology"]["power-armor-mk2"])

tech3.name = "fire-armor3"
tech3.prerequisites = {"power-armor-mk2", "refined-flammables-7"}
tech3.effects = {
{ type   = 'unlock-recipe',
  recipe = "fire-armor3"
  },  
}
 
tech3.unit = {
count = 500,
ingredients = {
  {"automation-science-pack", 1},
  {"logistic-science-pack"  , 1},
  {"military-science-pack"  , 1},
  {"chemical-science-pack"  , 1},
  {"utility-science-pack"   , 1},
  },
time = 30,
}

tech3.icons = {
  {
    icon = tech3.icon,
    tint = {r=1,g=0,b=0,--[[a=0.3--]]}
  },
}
	

tech3.enabled = true



data:extend({tech,fireArmor,recipe,tech1,fireArmor1,recipe1,tech2,fireArmor2,recipe2,tech3,fireArmor3,recipe3})